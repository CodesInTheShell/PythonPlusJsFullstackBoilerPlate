import { atom } from 'jotai';

export const usernameAtom = atom('');
