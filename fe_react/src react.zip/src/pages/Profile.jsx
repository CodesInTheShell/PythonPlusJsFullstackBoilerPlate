// import { useAtom } from 'jotai';
// import { authAtom } from '../atoms/authAtom';
// import { useEffect, useState } from 'react';
// import axios from 'axios';

// export default function Profile() {
//   const [auth] = useAtom(authAtom);
//   const [userData, setUserData] = useState(null);

//   useEffect(() => {
//     async function fetchData() {
//       try {
//         const response = await axios.get('http://127.0.0.1:5000/api/user/me', {
//           headers: { 'x-access-token': auth.token },
//         });
//         setUserData(response.data);
//       } catch (error) {
//         console.error('Failed to fetch user data', error);
//       }
//     }
//     fetchData();
//   }, [auth.token]);

//   return (
//     <div className="container">
//       <h2>Profile</h2>
//       {userData ? (
//         <div>
//           <p><strong>Username:</strong> {userData.username}</p>
//           {/* Add more user data fields as needed */}
//         </div>
//       ) : (
//         <p>Loading...</p>
//       )}
//     </div>
//   );
// }

// src/pages/Profile.jsx
import { useAtom } from 'jotai';
import { usernameAtom } from '../atoms/usernameAtom';
import { useEffect, useState } from 'react';
import axios from 'axios';

export default function Profile() {
  const [username] = useAtom(usernameAtom);
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      const token = localStorage.getItem('token');
      if (token) {
        const response = await axios.get('http://127.0.0.1:5000/api/user/me', {
          headers: { 'x-access-token': token },
        });
        setUserData(response.data);
      }
    };

    fetchData();
  }, []);

  return (
    <div className="container">
      <h2>Profile</h2>
      <p>Username: {username}</p>
      {userData && <pre>{JSON.stringify(userData, null, 2)}</pre>}
    </div>
  );
}
