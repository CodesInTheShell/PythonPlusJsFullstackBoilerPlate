// This page is just a placeholder to confirm successful login.
export default function Dashboard() {
    return (
      <div className="container">
        <h2>Welcome to the Dashboard</h2>
        <p>This is a protected route.</p>
      </div>
    );
  }